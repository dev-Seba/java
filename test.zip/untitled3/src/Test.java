import java.util.Scanner;
public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Podaj liczbe, ja dodam 1 ");
        Integer c = scan.nextInt();
        System.out.println(c+1);
    }
}
