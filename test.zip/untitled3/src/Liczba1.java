public class Liczba1 {
    public static void main(String args[]) {
        int i, m = 0, flag = 0;
        int n = 3; //it is the number to be checked
        m = n / 2;
        if (n == 0 || n == 1) {
            System.out.println(n + " nie jest liczbą pierwszą");
        } else {
            for (i = 2; i <= m; i++) {
                if (n % i == 0) {
                    System.out.println(n + " nie jest liczbą pierwszą");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0) {
                System.out.println(n + " jest liczbą pierwszą");
            }
        }//end of else
    }
}

